//creating the list item in the application

import React, { useEffect } from "react";
//import unique id for every list in the array
import { v4 as uuidv4 } from "uuid";

//props passed down from app.js called here
const Form = ({ input, setInput, todos, setTodos, editTodo, setEditTodo }) => {
  const updateTodo = (title, id, completed) => {
    const newTodo = todos.map((todo) =>
      todo.id === id ? { title, id, completed } : todo
    );
    setTodos(newTodo);
    setEditTodo("");
  };
  useEffect(() => {
    if (editTodo) {
      setInput(editTodo.title);
    } else {
      setInput("");
    }
  }, [setInput, editTodo]);

  //functionality for onClick
  const onInputChange = (e) => {
    setInput(e.target.value);
  };
  //functionaity for onFormsubmit
  const onFormSubmit = (e) => {
    e.preventDefault();
    if (!editTodo) {
      //id set to import, the title is set to input from user and the initial state is false
      setTodos([...todos, { id: uuidv4(), title: input, complete: false }]);
      setInput("");
    } else {
      updateTodo(input, editTodo.id, editTodo.completed);
    }
  };

  return (
    <form onSubmit={onFormSubmit}>
      <input
        type="text"
        placeholder="Enter a ToDo..."
        className="task-input"
        //adding value for the props
        value={input}
        required
        onChange={onInputChange}
      />

      <button className="button-add" type="submit">
        {editTodo ? "Okay" : "Add"}
      </button>
    </form>
  );
};

export default Form;
