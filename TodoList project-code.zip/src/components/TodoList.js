//this component will be responsible for displaying the TODO list items that are
//added from "Form"

import React from "react";

//call props from app.js here
const TodoList = ({ todos, setTodos, setEditTodo }) => {
  const handleDelete = ({ id }) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  const handleComplete = ({ todo }) => {
    setTodos(
      todos.map((item) => {
        if (item.id === todo.id) {
          return { ...item, completed: !item.completed };
        }
        return item;
      })
    );
  };

  const handleEdit = ({ id }) => {
    const findTodo = todos.find((todo) => todo.id === id);
    setEditTodo(findTodo);
    return {};
  };

  return (
    <div>
      {/* mapping through each todo item
      and displaying it on the screen */}
      {todos.map((todo) => (
        <li className="list-item" key={todo.id}>
          <input
            type="text"
            value={todo.title}
            className={`list ${todo.completed ? "complete" : ""}`}
            onChange={(e) => e.preventDefault()}
          />

          <div>
            {/* button elements to mark completion, editing, and deleting */}
            <button
              className="task-button"
              onclick={() => handleComplete(todo)}
            >
              <i className="button-complete"></i>
            </button>

            <button className="task-button" onClick={() => handleEdit(todo)}>
              <i className="button-edit"></i>
            </button>

            <button className="task-button" onClick={() => handleDelete(todo)}>
              <i className="button-delete"></i>
            </button>
          </div>
        </li>
      ))}
    </div>
  );
};

export default TodoList;
