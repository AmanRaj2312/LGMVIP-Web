import "./styles.css";
import React, { useState, useEffect } from "react";

//import components
import Header from "../src/components/Header";
import Form from "../src/components/Form";
import TodoList from "../src/components/TodoList";

const App = () => {
  //store the todo list items into a local storage
  const initialState = JSON.parse(localStorage.getItem("todos")) || [];

  //need to keep track of the user input
  const [input, setInput] = useState("");

  //need to keep track of the todo items in an empty array
  const [todos, setTodos] = useState(initialState);

  //need to keep track of the editing of the items
  const [editTodo, setEditTodo] = useState(null);

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  return (
    <div className="container">
      <div className="app-wrapper">
        <div className="">
          <Header />
          <p className="para">Add to the list, and delete them if need be</p>
        </div>

        <div>
          <Form
            //passing in props to the Form component
            input={input}
            setInput={setInput}
            todos={todos}
            setTodos={setTodos}
            editTodo={editTodo}
            setEditTodo={setEditTodo}
          />
        </div>

        <div className="">
          <TodoList
            //passing in pros
            todos={todos}
            setTodos={setTodos}
            setEditTodo={setEditTodo}
          />
        </div>
      </div>
    </div>
  );
};

export default App;
